class Network {
  // static const String baseUrl = "192.168.8.23:5000";
  static const String baseUrl = "https://bookbackend3.bruktiethiotour.com";
  static const String appPlayStoreUrl =
      "https://play.google.com/store/apps/details?id=";
  static const String appPackageName = "com.example.bookmobile";
}
